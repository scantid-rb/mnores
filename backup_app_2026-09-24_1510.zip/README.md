# Inventario de Repuestos para Barcos — V1

Aplicación web sencilla para gestionar el inventario de repuestos de una flota pequeña de barcos (~6 barcos, ~18 usuarios). Escrita en PHP 8.3 con SQLite. Sin frameworks JS, sin servicios externos, sin dependencias en la nube.

## Requisitos

- Linux, macOS o Windows con:
  - **PHP 8.3** o superior en línea de comandos
  - Extensiones PHP: `pdo`, `pdo_sqlite`, `gd`, `zip`, `xml`, `mbstring`
- **SQLite 3** (para consultas manuales, opcional)
- **Composer** (solo para instalar PhpSpreadsheet la primera vez)
- Cualquier servidor web capaz de ejecutar PHP:
  - Servidor embebido de PHP (`php -S`) — suficiente para uso local a bordo
  - Apache/Nginx tradicional con PHP-FPM (recomendado en hosting)
- 100 MB libres iniciales (crece con las fotografías)

## Instalación

1. **Copiar el proyecto** a la máquina destino, por ejemplo `/var/www/inventario`. La estructura debe conservarse tal cual (`public/`, `src/`, `data/`, `vendor/`, `router.php`, `composer.json`).
2. **Instalar dependencias** (solo si `vendor/` no viene incluido):
   ```bash
   composer install --no-dev --optimize-autoloader
   ```
3. **Permisos**: la carpeta `data/` y sus subdirectorios (`photos/`, `backups/`) deben ser escribibles por el usuario del servidor web (`www-data`, `apache`, etc.):
   ```bash
   chown -R www-data:www-data data/
   chmod 750 data/ data/photos data/backups
   ```
4. **Configurar el servidor web**:
   - **Servidor embebido (rápido para probar):**
     ```bash
     cd /var/www/inventario
     php -S 0.0.0.0:8080 -t public/ router.php
     ```
   - **Apache**: apuntar `DocumentRoot` a `public/`. El `.htaccess` incluido en `data/` bloquea el acceso HTTP a la BD y a las fotografías.
   - **Nginx**: apuntar `root` a `public/` y usar `try_files $uri /index.php;`. Denegar `location ~ ^/(data|src|vendor)/`.
5. **Abrir la aplicación en el navegador**. Al ser primera ejecución mostrará **CONFIGURACIÓN INICIAL → Nueva instalación**. Rellenar el formulario para crear el primer administrador. Se marcará como “administrador principal” (no podrá ser eliminado ni desactivado).
6. **Iniciar sesión** con las credenciales creadas.

### Ruta base / subdirectorio

Si la aplicación se aloja en `https://ejemplo.com/inventario/` en lugar de la raíz, editar `src/config.php` y cambiar:

```php
$BASE_PATH = '/inventario';
```

Debe empezar por `/` y **no** terminar en `/`. Cadena vacía = dominio raíz.

## Configuración

Menú **Configuración** (Administrador/Inspector). Se guardan los valores:

| Clave                  | Descripción                                 | Valor inicial |
|------------------------|---------------------------------------------|---------------|
| `app_name`             | Nombre de la aplicación (título HTML)       | Inventario de Repuestos |
| `app_title`            | Marca visible en la cabecera                | Repuestos a bordo |
| `company_name`         | Empresa/organización (opcional)             | *(vacío)*     |
| `backup_interval_days` | Intervalo del backup automático (días)      | 7             |
| `backup_retention_days`| Retención de backups de seguridad (días)    | 7             |
| `audit_retention_days` | Conservación de registros de auditoría (d)  | 90            |
| `disk_warning_percent` | Umbral para aviso de poco espacio (%)       | 20            |

Los cambios se aplican inmediatamente en la siguiente petición.

## Estructura de carpetas

```
inventario/
├── public/                    # DocumentRoot (único directorio expuesto)
│   ├── index.php              # Front controller
│   └── assets/style.css
├── src/
│   ├── config.php             # Constantes básicas y BASE_PATH
│   ├── bootstrap.php          # Sesión, cabeceras seguridad, auto-backup
│   ├── db.php                 # PDO + esquema + migraciones
│   ├── auth.php               # Roles y permisos
│   ├── csrf.php               # Token CSRF
│   ├── audit.php              # Registro de auditoría
│   ├── settings.php           # Configuración dinámica
│   ├── photos.php             # Procesado de imágenes (GD)
│   ├── backup.php             # Backups y restauración
│   ├── parts_util.php         # Utilidades y permisos del inventario
│   ├── helpers.php            # e(), url(), redirect(), render()
│   ├── actions/               # Un archivo por recurso
│   │   ├── install_get.php / install_post.php
│   │   ├── login_get.php / login_post.php / logout.php / account.php
│   │   ├── home.php
│   │   ├── users.php / boats.php / categories.php
│   │   ├── parts.php / export.php
│   │   ├── backups.php / settings.php / status.php
│   └── views/                 # Plantillas HTML
├── data/                      # NO accesible por HTTP (.htaccess)
│   ├── app.sqlite             # Base de datos
│   ├── installed.lock         # Marcador de instalación completada
│   ├── photos/                # Fotografías (JPEG)
│   └── backups/               # Backups automáticos, manuales y de seguridad
├── vendor/                    # PhpSpreadsheet + dependencias
├── router.php                 # Router para `php -S`
├── composer.json
└── README.md
```

## Creación de backup

- **Manual**: menú *Backups → “Crear backup manual”*. El ZIP se nombra `backup_manual_YYYY-MM-DD_HHMM.zip` y se guarda en `data/backups/`.
- **Automático**: se ejecuta cada `backup_interval_days` días al recibir una petición dinámica (nunca durante descargas de fotos, exportaciones o assets estáticos). Aparece un mensaje _“Realizando mantenimiento del sistema, por favor espere…”_ si otro proceso ya está ejecutándolo y, al terminar, _“El mantenimiento automático ha concluido. Ya puede utilizar la aplicación.”_ Los fallos se registran en `data/backups/.autobackup.fail` y en `audit_log`.
- **Descargar/eliminar**: desde la misma pantalla, listados por tipo (Manual, Automático, Seguridad).

### Contenido del ZIP

```
database.sqlite
photos/<id>.jpg
manifest.json  ← app_version, schema_version, created_at_utc, sqlite_sha256, photos_expected, photos_included
```

## Restauración

Menú *Backups → Restaurar* (solo Administrador). El proceso:

1. Verifica el ZIP (firma, `manifest.json`, `sqlite_sha256`, `PRAGMA integrity_check`, tablas mínimas, `schema_version ≤ actual`).
2. Pide confirmación.
3. Crea automáticamente un backup de seguridad del estado actual (`backup_seguridad_YYYY-MM-DD_HHMM.zip`).
4. Sustituye `data/app.sqlite` y `data/photos/`.
5. Vuelve a comprobar `PRAGMA integrity_check`.
6. Si algo falla, se intenta revertir al backup de seguridad. Si la reversión también falla, se muestra un error inequívoco al Administrador.
7. Cierra la sesión actual y redirige a `/login` (se debe iniciar sesión con las credenciales de la BD restaurada).

## Actualización manual

1. Detener el servidor web / `php -S`.
2. Sustituir los archivos de `public/`, `src/`, `router.php`, `composer.json` por los de la versión nueva. **No tocar** `data/` ni `vendor/` a menos que la versión nueva lo pida explícitamente.
3. Si cambian dependencias:
   ```bash
   composer install --no-dev --optimize-autoloader
   ```
4. Reiniciar el servidor. La aplicación aplicará automáticamente cualquier migración de esquema al primer acceso.
5. Comprobar en *Estado* que `Versión aplicación`, `Versión esquema` y `SQLite integrity_check` son correctos.

## Solución de problemas habituales

**“ERR_TOO_MANY_REDIRECTS” o bucle a `/install`**
- Falta el fichero `data/installed.lock`. Si la instalación se completó, crearlo manualmente con `date > data/installed.lock`.

**Errores 500 o pantalla en blanco**
- Revisar `error_log` del servidor (Apache/Nginx) o `stderr` de `php -S`.
- Comprobar permisos: `data/` debe ser escribible por PHP.
- Ejecutar `php -l src/bootstrap.php` para validar sintaxis tras un cambio.

**No se puede subir fotografía**
- Comprobar que `php.ini` permite subidas de al menos 8 MB (`upload_max_filesize`, `post_max_size`).
- Extensión `gd` habilitada (`php -m | grep -i gd`).

**Auto-backup no se ejecuta**
- Precisa un usuario autenticado navegando por rutas dinámicas. Si nadie entra durante el intervalo configurado, el siguiente acceso lo desencadenará.
- Revisar `data/backups/.autobackup.fail` para el último error.

**Restauración fallida**
- La aplicación intenta revertir al backup de seguridad. Si la reversión también falla, existe un ZIP en `data/backups/backup_seguridad_*.zip` que se puede aplicar manualmente:
  ```bash
  unzip -o backup_seguridad_YYYY-MM-DD_HHMM.zip -d /tmp/rest
  cp /tmp/rest/database.sqlite data/app.sqlite
  cp /tmp/rest/photos/*.jpg data/photos/ 2>/dev/null || true
  ```

**Baja el rendimiento con muchos accesos concurrentes**
- Este proyecto está pensado para 3–20 usuarios. Si se supera, usar Apache/Nginx + PHP-FPM en lugar del servidor embebido.

## Seguridad implementada

- Prepared statements (PDO) en todas las consultas.
- Escape con `htmlspecialchars` en todas las plantillas.
- Validación de entrada por longitud y patrón.
- Autorización backend en cada acción (403 al saltarse un permiso).
- CSRF token en todas las operaciones que modifican datos (POST).
- Contraseñas con `password_hash` (bcrypt), mínimo 8 caracteres.
- Sesiones con cookie `HttpOnly` + `SameSite=Lax`; `Secure` automático si la petición llega por HTTPS.
- Protección de fuerza bruta: 10 fallos por IP+usuario → bloqueo 5 min.
- SQLite y fotografías fuera del `DocumentRoot`; `.htaccess` con `Deny from all` y `php_flag engine off`.
- Uploads: validados con `getimagesize()` + `imagecreatefrom*` (rechaza contenido falso). Máximo 8 MB. Reescritos siempre como JPEG con redimensión a 1600×1200.
- Cabeceras HTTP: `X-Content-Type-Options: nosniff`, `X-Frame-Options: SAMEORIGIN`, `Referrer-Policy: same-origin`, `Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; ...`.

## Portabilidad

- No hay rutas absolutas en el código: todas se construyen con `url()` sobre `BASE_PATH`.
- Funciona en HTTP puro; usa HTTPS si el proxy o servidor lo termina.
- Sin dependencia de Emergent ni de servicios en la nube.
- Todos los datos residen en `data/`. Copiar esa carpeta = migrar la aplicación.

## Licencia y créditos

Aplicación desarrollada como proyecto interno para gestión de repuestos de barcos. Dependencia externa: [PhpSpreadsheet](https://phpspreadsheet.readthedocs.io/) (MIT).
