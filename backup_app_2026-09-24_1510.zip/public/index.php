<?php
declare(strict_types=1);

require __DIR__ . '/../src/bootstrap.php';

$path   = current_path();
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if (!is_installed()) {
    if ($path === '/install') {
        require __DIR__ . '/../src/actions/' . ($method === 'POST' ? 'install_post.php' : 'install_get.php');
        return;
    }
    redirect('/install');
}
if ($path === '/install') redirect('/');

// Rutas estáticas simples primero.
switch ($path) {
    case '/':
    case '/home':
        if ($method === 'GET') { require __DIR__ . '/../src/actions/home.php'; return; }
        break;
    case '/login':
        require __DIR__ . '/../src/actions/' . ($method === 'POST' ? 'login_post.php' : 'login_get.php');
        return;
    case '/logout':
        require __DIR__ . '/../src/actions/logout.php';
        return;
    case '/account':
        require __DIR__ . '/../src/actions/account.php';
        return;
}

// Rutas de recursos con posibles subrutas.
$resources = [
    '/users'      => 'users.php',
    '/boats'      => 'boats.php',
    '/categories' => 'categories.php',
    '/parts'      => 'parts.php',
    '/backups'    => 'backups.php',
    '/export'     => 'export.php',
    '/settings'   => 'settings.php',
    '/status'     => 'status.php',
    '/audit'      => 'audit_view.php',
];
foreach ($resources as $prefix => $file) {
    if ($path === $prefix || str_starts_with($path, $prefix . '/')) {
        require __DIR__ . '/../src/actions/' . $file;
        return;
    }
}

http_response_code(404);
echo '<!doctype html><meta charset="utf-8"><title>404</title>';
echo '<p style="font-family:sans-serif;padding:2rem">Página no encontrada. <a href="' . e(url('/')) . '">Inicio</a></p>';
